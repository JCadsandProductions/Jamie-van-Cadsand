** READ ME INFORMATION **

This template is completely made by Jamie van Cadsand, Under the GNU General Public License (2025). Programmed for Arduino (show 'www.arduino.cc').
You are able to do it your own risk (show license from 'www.gnu.org'). This is a 'empty project' file that falls under the GNU General Public License.

LAST UPDATED
2025/05/08, Version 1.1, Build 2

FEATURES
Version 1.1 (2025/05/08).
- Better Version Info.
- Added: a '// Import Templates' comment.
- Added: a '// Import Librarys' comment.
- Added: a '// Import Files' comment.
- Added: a '// TODO' comment after every comment.

Version 1.0 (2025/04/13).
- Created for use it as a 'empty project' file for your Arduino (show 'www.arduino.cc').

CONTACT ME
If you have an question, you are free to send me an e-mail.
Email Adress: jamievancadsand@gmail.com

The programmer.
