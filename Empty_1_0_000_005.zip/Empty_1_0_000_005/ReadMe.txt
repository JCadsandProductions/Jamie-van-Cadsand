** READ ME INFORMATION **

This template is completely made by Jamie van Cadsand, Under the GNU General Public License (2025). Programmed for Arduino (show 'www.arduino.cc').
You are able to do it your own risk (show license). This is a 'empty project' file that falls under the GNU General Public License (show 'www.gnu.org').

LAST UPDATED
2025/05/18, Version 1.0.000.005, Build 3

FEATURES
Version 1.0.000.005 (2025/05/18).
- 1.0.000.005: Added -> a '// TODO' comment after every comment.
- 1.0.000.004: Added -> a '// Import Files' comment.
- 1.0.000.003: Added -> a '// Import Librarys' comment.
- 1.0.000.002: Added -> a '// Import Templates' comment.
- 1.0.000.001: Better Version Info.
- 1.0.000.000: A Empty Source Code Main File for your Arduino Projects.

CONTACT ME
If you have an question, you are free to send me an e-mail.
Email Adress: jamievancadsand@gmail.com

The programmer.
